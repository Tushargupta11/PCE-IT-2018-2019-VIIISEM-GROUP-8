package com.example.user.poornimapayment;

public class UserInformation {

    public String name;
    public String mobile;

    public UserInformation(){


    }

    public UserInformation(String name, String mobile) {
        this.name = name;
        this.mobile = mobile;
    }
}
